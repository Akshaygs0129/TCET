package com.TCET;

public class Question_5 {
    public static void main(String[] args) {
        int[] crates = {5, 0, 7, 0, 1, 2, 0, 6, 0, 9}; // Taking one sample array as an example
        EmptyCrates(crates);
        for (int crate : crates) {
            System.out.print(crate + " ");
        }
    }

    public static void EmptyCrates(int[] crates) {
        int index = 0;
        for (int i = 0; i < crates.length; i++) {
            if (crates[i] != 0) {  // loop to swap the elements at "index" with "i"
                int temp = crates[index];
                crates[index] = crates[i];
                crates[i] = temp;
                index++;
            }
        }
    }
}