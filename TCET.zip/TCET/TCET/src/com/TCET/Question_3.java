package com.TCET;

import java.util.HashMap;
import java.util.Map;

public class Question_3 {
    public static void main(String[] args) {
        String text = "This is a test string. This string is for testing."; //input string
        String[] words = text.replaceAll("[^a-zA-Z ]", "").toLowerCase().split("\\s+"); //converting all letters to lower case
        Map<String, Integer> frequencyMap = new HashMap<>();

        for (String word : words) { //loop for counting
            if (!word.isEmpty()) {
                frequencyMap.put(word, frequencyMap.getOrDefault(word, 0) + 1);
            }
        }

        for (String key : frequencyMap.keySet()) {
            System.out.println(key + ": " + frequencyMap.get(key)); //output being displayed
        }
    }
}
