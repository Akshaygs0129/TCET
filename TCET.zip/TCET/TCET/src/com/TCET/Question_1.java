package com.TCET;
@FunctionalInterface
interface Sayable { // interface sayable
    String say(String message); //abstract method say
}

public class Question_1 {
	public static void main(String[] args) {
        Sayable sayable = (message) -> {
            return "Hello, " + message; //one string parameter and returns a message 
        };
        System.out.println(sayable.say("Good Morning... Have a Nice Day."));
    }

}
